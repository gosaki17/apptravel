package com.exemple.apptravel.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Recommendation {

    private String name;
    private String imageUrl;
    @Id
    @GeneratedValue
    private int id;
    public Recommendation( int id ,String name, String imageUrl) {
        this.id=id;
        this.name = name;
        this.imageUrl = imageUrl;
    }

    public Recommendation() {

    }

    public void setId(int intExact) {
    }

    public void setUrl(String url) {
    this.imageUrl=imageUrl;
    }
}


