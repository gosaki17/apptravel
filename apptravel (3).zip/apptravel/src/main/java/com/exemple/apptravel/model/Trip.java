package com.exemple.apptravel.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class Trip {

    @Id
    private Long id;
    private String destination;
    private String description;
    private String duration;
    private int participants;
    private double budget;
    private String interests;
    private LocalDate startDate;
    private LocalDate endDate;
    private String tripType; // Added tripType field
}