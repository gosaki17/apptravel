package com.exemple.apptravel.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
public class TripPreferences {

    // Getters and setters
    private String destination;
    private LocalDate startDate;
    private LocalDate endDate;
    private List<String> activities;
    private int budget;


    public TripPreferences() {
    }


    public TripPreferences(String destination, LocalDate startDate, LocalDate endDate, List<String> activities, int budget) {
        this.destination = destination;
        this.startDate = startDate;
        this.endDate = endDate;
        this.activities = activities;
        this.budget = budget;
    }

    // toString() for debugging (optional)
    @Override
    public String toString() {
        return "TripPreferences{" +
                "destination='" + destination + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", activities=" + activities +
                ", budget=" + budget +
                '}';
    }
}