package com.exemple.apptravel.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", unique = true, length = 50)
    private String username;

    @Column(name = "password")
    private String password;

    @Column(name = "email", unique = true,length = 50)
    private String email;

    // Add other fields and getters/setters as needed
}