package com.exemple.apptravel.model.config;

import com.exemple.apptravel.model.Recommendation;
import com.exemple.apptravel.model.repository.RecommendationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final RecommendationRepository recommendationRepository;

    public DataInitializer(RecommendationRepository recommendationRepository) {
        this.recommendationRepository = recommendationRepository;
    }

    @Override
    public void run(String... args) {
        recommendationRepository.save(new Recommendation(1,"Jamaa El Fna Square", "https://i.pinimg.com/736x/80/75/29/807529528b3d394e1b7e6b3315b3370a.jpg"));
        recommendationRepository.save(new Recommendation(2,"Hassan II Mosque Esplanade", "https://i.pinimg.com/736x/aa/a8/81/aaa88144bab433008c5ab328c456a37a.jpg"));
        recommendationRepository.save(new Recommendation(3,"Place des Nations Unies", "https://i.pinimg.com/736x/0b/6d/85/0b6d859d10802e8bfb6da715180435f1.jpg"));
        recommendationRepository.save(new Recommendation(4,"Bab Mansour", "https://i.pinimg.com/736x/71/27/9b/71279b8843d90823926f02584fc22190.jpg"));
        recommendationRepository.save(new Recommendation(5,"Place Al Alaoui", "https://i.pinimg.com/736x/29/c6/cb/29c6cbfb7d577e68db6b5e026d2aec1d.jpg"));
        recommendationRepository.save(new Recommendation(6,"Skala", "https://i.pinimg.com/736x/1f/f1/ca/1ff1cab5650a9ed1d344573d9c2b1b91.jpg"));
        recommendationRepository.save(new Recommendation(7,"Ras El Ma", "https://lh3.googleusercontent.com/p/AF1QipO78zoJPcqslx-D2kxSlIuW98CnC-6i-Lp-NCPi=s1360-w1360-h1020-rw"));
        recommendationRepository.save(new Recommendation(8,"Marina", "https://i.pinimg.com/736x/83/d8/bc/83d8bc578ca0d242af5fab2eb67e8b83.jpg"));
    }
}