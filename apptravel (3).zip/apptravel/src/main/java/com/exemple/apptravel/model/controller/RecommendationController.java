package com.exemple.apptravel.model.controller;

import com.exemple.apptravel.model.Recommendation;
import com.exemple.apptravel.model.dto.RecommendationDTO;
import com.exemple.apptravel.model.service.RecommendationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {

    @Autowired
    private RecommendationService recommendationService;

    @GetMapping("/{id}")
    public ResponseEntity<RecommendationDTO> getRecommendation(@PathVariable Long id) {
        RecommendationDTO dto = recommendationService.getRecommendationDTO(Math.toIntExact(id));
        if (dto != null) {
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Recommendation> createRecommendation(@RequestBody RecommendationDTO dto) {
        Recommendation recommendation = recommendationService.createRecommendation(dto);
        return ResponseEntity.ok(recommendation);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Recommendation> updateRecommendation(@PathVariable Long id, @RequestBody RecommendationDTO dto) {
        Recommendation recommendation = recommendationService.updateRecommendation(Math.toIntExact(id), dto);
        if (recommendation != null) {
            return ResponseEntity.ok(recommendation);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecommendation(@PathVariable Long id) {
        recommendationService.deleteRecommendation(Math.toIntExact(id));
        return ResponseEntity.noContent().build();
    }
}