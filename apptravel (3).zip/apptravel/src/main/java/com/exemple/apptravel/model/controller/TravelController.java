package com.exemple.apptravel.model.controller;

import com.exemple.apptravel.model.dto.TravelPreferencesDto;
import com.exemple.apptravel.model.dto.TravelResultDto;
import com.exemple.apptravel.model.service.TravelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/travel")
@CrossOrigin(origins = "http://localhost:5173", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS}, allowedHeaders = "*", allowCredentials = "true")
public class TravelController {

    private final TravelService travelService;

    @Autowired
    public TravelController(TravelService travelService) {
        this.travelService = travelService;
    }

    @PostMapping("/results")
    public ResponseEntity<List<TravelResultDto>> getTravelResults(@RequestBody TravelPreferencesDto preferences) {
        List<TravelResultDto> results = travelService.generateTravelResults(preferences);
        return ResponseEntity.ok(results);
    }
}