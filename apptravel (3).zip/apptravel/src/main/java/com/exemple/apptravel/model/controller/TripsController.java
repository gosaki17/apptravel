package com.exemple.apptravel.model.controller;

import com.exemple.apptravel.model.dto.PlaceDTO;
import com.exemple.apptravel.model.dto.TripDTO;
import com.exemple.apptravel.model.service.TripService;
import com.exemple.apptravel.model.response.MessageResponse;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/trips")
public class TripsController {

    private final TripService tripService;

    @Autowired
    public TripsController(TripService tripService) {
        this.tripService = tripService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<TripDTO> getTripDetails(@PathVariable Long id) {
        TripDTO tripDTO = tripService.getTripDetails(id);
        if (tripDTO != null) {
            return ResponseEntity.ok(tripDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/create")
    public ResponseEntity<?> createTrip(@RequestBody TripDTO tripDTO) {
        tripService.createTrip(tripDTO);
        return ResponseEntity.ok(new MessageResponse("Trip created successfully"));
    }

    @GetMapping("/places/{destination}")
    public ResponseEntity<List<PlaceDTO>> getPlacesByDestination(@PathVariable String destination) {
        List<PlaceDTO> places = tripService.getPlacesByDestination(destination);
        return ResponseEntity.ok(places);
    }

    @PostMapping("/calculate-price")
    public ResponseEntity<BigDecimal> calculatePrice(@RequestBody CalculatePriceRequest request) {
        BigDecimal totalPrice = tripService.calculatePrice(request.getBudget(), request.getPlaceIds());
        return ResponseEntity.ok(totalPrice);
    }

    // Inner class for calculate price request
    @Setter
    @Getter
    static class CalculatePriceRequest {
        private BigDecimal budget;
        private List<Long> placeIds;

    }
}