// backend/src/main/java/com/exemple/apptravel/model/controller/UserController.java

package com.exemple.apptravel.model.controller;

import com.exemple.apptravel.model.request.RegisterRequest; // Import the RegisterRequest DTO
import com.exemple.apptravel.model.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")
@RestController
public class UserController {

    private final UserService userService; // Use constructor injection

    @Autowired
    public UserController(UserService userService) { // Constructor
        this.userService = userService;
    }

    @PostMapping("/register")
    public String registerUser(@RequestBody RegisterRequest request) { // Use RegisterRequest DTO
        return userService.registerUser(request.getUsername(), request.getEmail(), request.getPassword());
    }
}
