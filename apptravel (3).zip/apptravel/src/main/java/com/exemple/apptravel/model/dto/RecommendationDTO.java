package com.exemple.apptravel.model.dto;

import lombok.Data;

@Data
public class RecommendationDTO {

    private Long id;


    private String name;

    private String url;

}