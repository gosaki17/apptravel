package com.exemple.apptravel.model.dto;

import lombok.Data;

@Data
public class TravelPreferencesDto {
    private String budget;
    private String destination;
    private String interests;
    private String duration;
    private String participants;
    private String ageCategory;
}