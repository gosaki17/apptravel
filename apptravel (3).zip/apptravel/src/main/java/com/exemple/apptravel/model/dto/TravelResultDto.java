package com.exemple.apptravel.model.dto;

import lombok.Data;

@Data
public class TravelResultDto {
    private String destination;
    private String description;
    private double price;
    // Removed imageUrl
}