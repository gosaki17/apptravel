package com.exemple.apptravel.model.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class TripDTO {
    private Long id;
    private String destination;
    private String description;
    private String duration;
    private int participants;
    private double budget;
    private String interests;
    private LocalDate startDate;
    private LocalDate endDate;
    private String tripType; // Added tripType field
}