package com.exemple.apptravel.model.repository;
import com.exemple.apptravel.model.Recommendation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecommendationRepository extends JpaRepository<Recommendation, Long> {
}
