package com.exemple.apptravel.model.repository;

import com.exemple.apptravel.model.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByTripType(String tripType); // Added method to find trips by type
}