package com.exemple.apptravel.model.response;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JwtResponse {
    private String token;
    private String username;

    public JwtResponse(String token) {
        this.token = token;
        this.username = username;
    }

}