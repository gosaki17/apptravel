// AuthService.java
package com.exemple.apptravel.model.service;

import com.exemple.apptravel.model.User;
import com.exemple.apptravel.model.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public boolean authenticate(String username, String password) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            String encodedPasswordFromDatabase = user.getPassword();

            // Log the encoded passwords and the result of the comparison
            System.out.println("Encoded password from database: " + encodedPasswordFromDatabase);
            System.out.println("Password entered by user: " + password);
            boolean passwordsMatch = passwordEncoder.matches(password, encodedPasswordFromDatabase);
            System.out.println("Passwords match: " + passwordsMatch);

            return passwordsMatch;
        }
        return false;
    }

    public void register(String email, String username, String password) {
        if (userRepository.existsByUsername(username)) {
            throw new RuntimeException("Username is already taken");
        }

        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email is already taken");
        }

        User user = new User();
        user.setEmail(email);
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        userRepository.save(user);
    }
}