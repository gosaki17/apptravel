package com.exemple.apptravel.model.service;

import com.exemple.apptravel.model.Recommendation;
import com.exemple.apptravel.model.dto.RecommendationDTO;
import com.exemple.apptravel.model.repository.RecommendationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RecommendationService {

    @Autowired
    private RecommendationRepository recommendationRepository;

    public RecommendationDTO getRecommendationDTO(int id) {
        Recommendation recommendation = recommendationRepository.findById((long) id).orElse(null); // Cast id to Long
        if (recommendation != null) {
            RecommendationDTO dto = new RecommendationDTO();
            dto.setId((long) recommendation.getId());
            dto.setName(recommendation.getName());
            dto.setUrl(recommendation.getImageUrl());
            return dto;
        }
        return null;
    }

    public Recommendation createRecommendation(RecommendationDTO dto) {
        Recommendation recommendation = new Recommendation();
        recommendation.setId(Math.toIntExact(dto.getId())); // Directly use dto.getId()
        recommendation.setName(dto.getName());
        recommendation.setUrl(dto.getUrl());
        return recommendationRepository.save(recommendation);
    }

    public Recommendation updateRecommendation(int id, RecommendationDTO dto) { // Change Long id to int id
        Recommendation recommendation = recommendationRepository.findById((long) id).orElse(null); // Cast id to Long
        if (recommendation != null) {
            recommendation.setName(dto.getName());
            recommendation.setUrl(dto.getUrl());
            // Map other fields as needed
            return recommendationRepository.save(recommendation);
        }
        return null;
    }

    public void deleteRecommendation(int id) { // Change Long id to int id
        recommendationRepository.deleteById((long) id); // Cast id to Long
    }
}