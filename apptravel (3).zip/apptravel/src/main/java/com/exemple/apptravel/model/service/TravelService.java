package com.exemple.apptravel.model.service;

import com.exemple.apptravel.model.Place;
import com.exemple.apptravel.model.dto.TravelPreferencesDto;
import com.exemple.apptravel.model.dto.TravelResultDto;
import com.exemple.apptravel.model.repository.PlaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TravelService {

    private final PlaceRepository placeRepository;

    @Autowired
    public TravelService(PlaceRepository placeRepository) {
        this.placeRepository = placeRepository;
    }

    public List<TravelResultDto> generateTravelResults(TravelPreferencesDto preferences) {
        List<TravelResultDto> results = new ArrayList<>();

        if (preferences.getDestination() != null) {
            List<Place> places = placeRepository.findByDestination(preferences.getDestination());
            for (Place place : places) {
                TravelResultDto result = new TravelResultDto();
                result.setDestination(place.getDestination());
                result.setDescription(place.getDescription());
                result.setPrice(place.getPrice());
                results.add(result);
            }
        } else {
            // If destination is not provided, return some default results or an empty list
            TravelResultDto defaultResult = new TravelResultDto();
            defaultResult.setDestination("No Destination Specified");
            defaultResult.setDescription("Please provide a destination to get results.");
            results.add(defaultResult);
        }

        return results;
    }
}