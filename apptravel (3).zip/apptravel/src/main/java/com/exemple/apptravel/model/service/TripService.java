package com.exemple.apptravel.model.service;

import com.exemple.apptravel.model.Place;
import com.exemple.apptravel.model.Trip;
import com.exemple.apptravel.model.dto.PlaceDTO;
import com.exemple.apptravel.model.dto.TripDTO;
import com.exemple.apptravel.model.repository.PlaceRepository;
import com.exemple.apptravel.model.repository.TripRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TripService {

    private final TripRepository tripRepository;
    private final PlaceRepository placeRepository;

    @Autowired
    public TripService(TripRepository tripRepository, PlaceRepository placeRepository) {
        this.tripRepository = tripRepository;
        this.placeRepository = placeRepository;
    }

    public TripDTO getTripDetails(Long tripId) {
        return tripRepository.findById(tripId)
                .map(this::mapTripToDTO)
                .orElse(null);
    }

    public void createTrip(TripDTO tripDTO) {
        Trip trip = mapDTOtoTrip(tripDTO);
        tripRepository.save(trip);
    }

    // Helper method to map Trip to TripDTO
    private TripDTO mapTripToDTO(Trip trip) {
        TripDTO tripDTO = new TripDTO();
        tripDTO.setId(trip.getId());
        tripDTO.setDestination(trip.getDestination());
        tripDTO.setDescription(trip.getDescription());
        tripDTO.setDuration(trip.getDuration());
        tripDTO.setParticipants(trip.getParticipants());
        tripDTO.setBudget(trip.getBudget());
        tripDTO.setInterests(trip.getInterests());
        tripDTO.setStartDate(trip.getStartDate());
        tripDTO.setEndDate(trip.getEndDate());
        tripDTO.setTripType(trip.getTripType());
        return tripDTO;
    }

    // Helper method to map TripDTO to Trip
    private Trip mapDTOtoTrip(TripDTO tripDTO) {
        Trip trip = new Trip();
        trip.setId(tripDTO.getId());
        trip.setDestination(tripDTO.getDestination());
        trip.setDescription(tripDTO.getDescription());
        trip.setDuration(tripDTO.getDuration());
        trip.setParticipants(tripDTO.getParticipants());
        trip.setBudget(tripDTO.getBudget());
        trip.setInterests(tripDTO.getInterests());
        trip.setStartDate(tripDTO.getStartDate());
        trip.setEndDate(tripDTO.getEndDate());
        trip.setTripType(tripDTO.getTripType());
        return trip;
    }

    public BigDecimal calculatePrice(BigDecimal budget, List<Long> placeIds) {
        if (placeIds == null || placeIds.isEmpty()) {
            return budget.multiply(BigDecimal.valueOf(1.20));
        }

        BigDecimal totalPrice = placeRepository.findAllById(placeIds)
                .stream()
                .map(place -> BigDecimal.valueOf(place.getPrice()))
                .reduce(budget, BigDecimal::add);

        return totalPrice.multiply(BigDecimal.valueOf(1.20));
    }

    public List<PlaceDTO> getPlacesByDestination(String destination) {
        return placeRepository.findByDestination(destination)
                .stream()
                .map(this::convertToPlaceDTO)
                .collect(Collectors.toList());
    }

    private PlaceDTO convertToPlaceDTO(Place place) {
        PlaceDTO placeDTO = new PlaceDTO();
        placeDTO.setId(place.getId());
        placeDTO.setDestination(place.getDestination());
        placeDTO.setName(place.getName());
        placeDTO.setPrice(BigDecimal.valueOf(place.getPrice()));
        placeDTO.setDescription(place.getDescription());
        return placeDTO;
    }

    public List<TripDTO> getTripsByType(String tripType) {
        return tripRepository.findByTripType(tripType)
                .stream()
                .map(this::mapTripToDTO)
                .collect(Collectors.toList());
    }
}