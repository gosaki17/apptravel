

package com.exemple.apptravel.model.service;

import com.exemple.apptravel.model.User;
import com.exemple.apptravel.model.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public String registerUser(String username, String email, String password) {
        // Check for duplicate username or email
        if (userRepository.findByUsername(username).isPresent()) {
            return "Username already exists";
        }
        if (userRepository.findByEmail(email).isPresent()) {
            return "Email already exists";
        }

        // Hash the password
        String hashedPassword = passwordEncoder.encode(password);

        // Create a new User object
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(hashedPassword);

        // Save the user to the database
        userRepository.save(user);

        return "User registered successfully";
    }
}