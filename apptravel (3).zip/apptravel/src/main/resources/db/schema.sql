CREATE TABLE user (
                      id BIGINT AUTO_INCREMENT PRIMARY KEY,
                      username VARCHAR(255),
                      email VARCHAR(255),
                      password VARCHAR(255)
);

CREATE TABLE trip (
                      id BIGINT AUTO_INCREMENT PRIMARY KEY,
                      destination VARCHAR(255),
                      description TEXT,
                      duration VARCHAR(255)
);

CREATE TABLE recommendation (
                                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                recommendationText TEXT
);
